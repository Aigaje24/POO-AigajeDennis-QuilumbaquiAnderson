/**
 * 
 */
/**
 * 
 */
module MyOutPutVariableProject {
}